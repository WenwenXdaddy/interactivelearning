# 部署到 learning.jiadi.ai

## 当前状态

2026-09-15：站点项目已制作并通过本地检查；**远程 GitHub 仓库未由本轮创建，Cloudflare 未部署，DNS / 证书 / Git 自动部署未连接**。

已实际检查现有 GitHub 连接：账号为 `WenwenXdaddy`；当前可访问仓库列表不含 `learning-lab`，该路径读取返回 404。可调用工具支持已有仓库读写，但没有建仓库动作。插件目录中也未找到 Cloudflare 连接。没有搜取、复用或暴露其他项目的凭证。

## A. 推荐：电脑上一次执行首次发布助手

先准备官方工具：Node.js 22+、Git、GitHub CLI。登录和授权全部在官方浏览器页面完成。

```powershell
# 在解压后的 learning-lab-site 目录里
node scripts/publish.mjs --all
```

脚本执行顺序：安装 Wrangler → 构建与检查 → GitHub 登录及身份检查 → 创建私有仓库/向已有空私有仓库推送 → Cloudflare 登录 → 部署 → 读取正式网站验证。

保护措施：不改仓库可见性；不覆盖非空远程仓库；不强制推送；不改其他 Git remote；不把源文件/测试目录当作静态目录；不要求在聊天中提供 token；发现域名响应为别的站点时停止。不能核验 Zone 所属和同名 Worker 是否为本项目时，操作者必须先检查 Cloudflare 控制台，不能盲目确认覆盖。

部分成功无需回滚已创建仓库。例如 GitHub 成功、Cloudflare 失败后，使用：

```bash
node scripts/publish.mjs --cloudflare
```

## B. 已有本地 CLI 或使用 Codex / Claude Code 时的最小手工路线

该路线是助手的透明替代，不要与 A 重复创建仓库。

```bash
npm install
npm test
# 先审查目标仓库是否已存在，再初始化/推送。不要强制覆盖已有远程内容。
git init -b main
git add .
git commit -m "Initial learning site"
gh auth login --hostname github.com --git-protocol https --web
gh repo create WenwenXdaddy/learning-lab --private --source=. --remote=origin --push
npx wrangler login
npx wrangler whoami
npm run deploy
npm run verify:live
```

确认 GitHub 登录用户为 `WenwenXdaddy`，Cloudflare 登录的是拥有有效 `jiadi.ai` Zone 的账号。Git 需要已配置本地提交身份。既有仓库/本地 Git 情况下不要照抄初始化命令，先读现状。

## C. 后续自动发布：一次性连接 Cloudflare Builds

成功首次发布后，在 **learning-lab** Worker 的 **Settings → Builds** 中连接目标 GitHub 仓库。若后台界面布局发生变化，以官方 Builds 文档为准。

| 字段 | 值 |
|---|---|
| 仓库 | `WenwenXdaddy/learning-lab` |
| 生产分支 | `main` |
| 项目根目录 | 仓库根目录 |
| Build command | `npm run test` |
| Deploy command | `npx wrangler deploy` |
| 静态资源目录 | 配置中的 `./public` |
| Worker 名称 | `learning-lab` |

发布助手**没有自动建立这个 Git Builds 连接**。连接完成后需用一次真实提交验证自动发布。不要同时配置另一套 GitHub Actions 自动部署，以免重复发布。

本包有一个小构建步骤：从目录元数据和源课程生成 `public/`、校验课程脚本完整性、生成 CSP 脚本散列。它不是 React/Next.js 构建，预览也不需要安装依赖。

## 域名和访问范围

`wrangler.jsonc` 已声明：

```json
"routes": [{"pattern": "learning.jiadi.ai", "custom_domain": true}]
```

Wrangler 在有权限且 Zone 可用时应用这项自定义域名配置。写入配置不代表 DNS 已修改。若目标主机名已绑定其他 Worker、Pages 或存在冲突 DNS 记录，先查清，不删除整个 Zone，也不改动 `jiadi.ai` 主站或 Macro Terminal 的映射。

本项目不需要手写 CNAME 到某台服务器，不使用 `pages.dev`，也不通过 MLT 的 API。

默认 `workers_dev=false`、`preview_urls=false`，只声明用户指定域名，避免同时出现未管理的额外访问入口。需要分支预览时可以明确开启并设置适当访问控制；当前不能声称已提供线上预览地址。

此配置是公开静态网站。私有 GitHub 仓库不是访问控制；如需私密访问，应另设 Cloudflare Access，并审查所有启用的域名入口。

## 上线核验

```bash
npm run verify:live
```

该程序只执行读取，检查首页标识、manifest、两课内容散列、HTTP 安全头、离线下载响应和真实 404 状态。刚发布后证书或域名尚未就绪时可能暂时失败；失败必须说明，不得当作“已上线”。

还需手工完成：iPhone Safari 参数联动、词典关闭、重新打开网页后的本地存储、下载/导出、两课相互返回，以及网络断开后的下载版学习体验。

## 常规更新

```bash
npm test
# 检查变更，然后 commit / push 到已连接的 main
```

没有连接 Builds 时，用 `npm run deploy` 手工发布。不要反复运行首次 `--all` 助手。

发布前先提交本地源文件和生成文件，发布失败不会自动撤回 Git 提交。回滚时应按已验证版本恢复源码/静态资源并重新部署，不强推改写仓库历史。

## 官方参考（2026-09-15 核对）

- Workers 静态资源：https://developers.cloudflare.com/workers/static-assets/
- 自定义域名与 Wrangler 配置：https://developers.cloudflare.com/workers/wrangler/configuration/
- Workers Builds：https://developers.cloudflare.com/workers/ci-cd/builds/
- 构建配置：https://developers.cloudflare.com/workers/ci-cd/builds/configuration/
- GitHub CLI 建仓库：https://cli.github.com/manual/gh_repo_create
- GitHub CLI 官方下载：https://cli.github.com/
- Node.js：https://nodejs.org/

工具的安装、登录和远程发布没有在当前环境端到端执行；以上不是账户权限或线上状态的证明。
