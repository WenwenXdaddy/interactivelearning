# JIADI 学习实验室

**固定域名：`learning.jiadi.ai`**  
**目标私有仓库：`WenwenXdaddy/learning-lab`**  
**站点整合版本：1.0.0**

> 这个文件包是已经构建的站点项目，不是“已经上线”的证明。本轮没有创建远程仓库、部署到 Cloudflare 或修改 DNS。完成授权发布后，使用 `npm run verify:live` 核验。

## 本次包含

- 响应式首页：课程卡片、主题筛选、搜索、明暗主题、学习手册和独立 HTML 下载。
- 黄金波动率实验室 v2：10 个学习站；原始 JavaScript 保持逐字节一致。
- 未知投资实验室 v1：9 个学习站；原始 JavaScript 保持逐字节一致。
- 两课新增返回首页入口和固定域名的 canonical 元数据；不合并状态、模型或样式。
- 两门原始课程和 Markdown 学习手册保留在 `content/courses/`；下载版 HTML 与原件一致。
- Cloudflare Workers Static Assets 配置、只读上线验收程序、首次发布助手及 agent 接入约定。

## 在电脑上预览

需要 Node.js 22 或更新版本。预览和本地完整性检查不需要先安装 npm 包。

```bash
npm test
npm run preview
```

打开 `http://127.0.0.1:4173`。也可打开 `public/index.html` 浏览目录；课程本地 HTML 的脚本、存储和导出是否可用取决于浏览器。完整网站导航建议用上述本地 HTTP 预览。

## 第一次发布

先在电脑上安装 Node.js、Git 和 GitHub CLI（`gh`）。这些是开发工具，不是学习者使用网站时的依赖。

```bash
node scripts/publish.mjs --all
```

助手会请求 GitHub / Cloudflare 的官方浏览器登录，在正确 GitHub 账号下创建私有仓库，上传这套代码，再发布到配置中指定的 `learning.jiadi.ai`。不会接收或要求你把 API token 发到聊天。

重要边界：该助手已做语法检查，**没有在已授权的真实账号中端到端执行过**。有多个 Cloudflare 账号、无有效 Zone、已有同名 Worker/DNS 映射或 OAuth 权限不匹配时，应停止并检查，不要盲目确认替换。

若远程仓库已创建成功，但 Cloudflare 步骤失败，只重试：

```bash
node scripts/publish.mjs --cloudflare
```

`--all` 是首次发布助手，不是日常更新命令。它拒绝覆盖已有非空仓库。具体配置和正常更新流程见 [DEPLOYMENT.md](DEPLOYMENT.md)。

## 项目布局

```text
learning-lab-site/
├── content/                  # 两门原课程、手册及课程截图；不作为静态目录发布
├── courses.json              # 首页课程目录元数据
├── templates/home.html       # 首页源模板
├── public/                   # 自动构建输出；只有这里会部署
│   ├── index.html
│   ├── courses/<slug>/index.html
│   ├── courses/<slug>/study-notes.md
│   ├── downloads/<slug>.html
│   ├── assets/
│   ├── _headers
│   ├── site-manifest.json
│   ├── sitemap.xml
│   └── 404.html
├── scripts/                  # 构建、检查、本地预览、发布与上线核验
├── validation/               # 验收证据；不作为静态目录发布
├── wrangler.jsonc
├── Publish.ps1               # Windows 包装入口
├── DEPLOYMENT.md
└── AGENTS.md
```

`public/` 由构建脚本生成，不要只修改其中的首页后忘了源模板。两课模型要更新时修改 `content/courses/` 中的副本，执行回归检查，再重新构建。

## 添加下一门课

用 `interactive-learning-lab` 技能制作并验收新课，将 HTML 和学习笔记放到 `content/courses/<slug>/`，将真实截图放到 `content/previews/<slug>.webp`，再更新 `courses.json`。

当前导航注入器针对这两门课的 `<div class="brand">` 结构实现；新课程不匹配时会显式报错，应适配其入口，不能靠替换标题就宣称完成接入。

## 学习记录和隐私

- 首页只保存自己的明暗主题，不读取课程的个人决策卡。
- 两课沿用各自的浏览器存储命名空间；不会跨设备同步，也不会从此前的文件地址或其他域名自动迁移。
- 本次没有扩展原课程的保存范围。黄金页的章节浏览、作答、主题及复习词，与未知页的模型参数和决策记录，应以原课程实际实现为准；不要假定所有控件都会在刷新后恢复。
- 下载的学习手册是课程资料；要保存个人参数和答案，请使用课内“导出笔记”。
- 私有仓库不等于私有网站。此配置不带访问登录；成功部署后网页可公开访问。需要限制访问时在 Cloudflare 中设置 Access。
- 未加入遥测、交易账户接口、后端数据库、Service Worker 或自动离线缓存。

## 依赖与可复现性

网站运行不需要在线脚本、外部字体或 API。Wrangler 仅为发布工具，`package.json` 指定 4.x；本环境无法访问 npm registry，因此未伪造 `package-lock.json`。首次 `npm install` 成功后，应审阅并提交生成的锁文件。锁定后其他环境使用 `npm ci`。

## 验收

`npm test` 执行 24 项静态完整性检查；浏览器测试和本地 HTTP 服务测试的范围详见 `validation/QA_REPORT.md`。本轮浏览器的 HTTP 导航受环境策略限制，交互测试通过离线 DOM 和内存存储替身完成；这不是线上域名、原生存储或真机 Safari 验收。

本项目没有替用户或原文作者授予新的开源许可证。原课程的来源说明和研究日期保持不变；站点上线日期不能当作研究刷新日期。
