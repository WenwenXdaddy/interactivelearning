# 给 Codex / Claude Code 的接续任务

直接使用本包，**不要重新制作两门课程**。

目标：将这个独立静态学习站发布到 `learning.jiadi.ai`，私有仓库 `WenwenXdaddy/learning-lab`。

先阅读 `AGENTS.md`、`DEPLOYMENT.md` 和 `validation/QA_REPORT.md`。运行 `npm test` 后，检查本机 GitHub/Cloudflare 身份、现有目标仓库及域名映射。授权应通过官方浏览器流程或用户本机已配置的凭证，不让用户把 token 粘贴到聊天。

可以用 `node scripts/publish.mjs --all` 进行首次发布；若远程仓库已非空，助手会停止，此时必须读取和核对已有内容，不强制覆盖、不切换到别的仓库。若 GitHub 步骤已完成而 Cloudflare 步骤未完成，使用 `--cloudflare`。

Cloudflare 自动 Git Builds 仍需在账号内显式连接；完成后用一次实际提交验证。只有正式域名可访问、内容散列和功能核验通过，才能报告“已上线”。输出仓库 URL、提交 SHA、部署版本、正式地址、已测/未测项目。

禁止修改 `macro-liquidity-terminal`、`little-math-kitchen`、主域名的现有项目，禁止添加数据库、登录系统、运行时 API 或遥测。
